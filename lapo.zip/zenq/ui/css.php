	<!-- Icons-->
	<link rel="icon" type="image/ico" href="./img/favicon.ico" sizes="any">
	<link href="assets/css/coreui-icons.min.css" rel="stylesheet">
	<link href="assets/css/flag-icon.min.css" rel="stylesheet">
	<!-- Main styles for this application-->
	<link href="assets/css/style.css" rel="stylesheet">
	<link href="assets/vendors/pace-progress/css/pace.min.css" rel="stylesheet">
	<script src="https://kit.fontawesome.com/5f98ed3b44.js" crossorigin="anonymous"></script>
	<link href="assets/css/zenq.css" rel="stylesheet">
