	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/popper.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/pace.min.js"></script>
	<script src="assets/js/perfect-scrollbar.min.js"></script>
	<script src="assets/js/coreui.min.js"></script>
