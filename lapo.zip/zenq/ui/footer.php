<footer class="app-footer">
	<div>
		<span>&copy; 2020 Lapo.</span>
	</div>
	<div class="ml-auto">
		<span>Powered by</span>
		<img src="assets/img/paymedix.jpg" style="height: 24px;">
	</div>
</footer>